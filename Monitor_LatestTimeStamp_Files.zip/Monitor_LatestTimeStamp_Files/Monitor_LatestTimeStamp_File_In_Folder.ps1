# Script name   : Monitor_LatestTimeStamp_File_In_Folder.ps1
# Written by    : Sandesh Rane
# Date          : 9-April-2019
# Description   : Purpose of the script: Custome file monitoring requiremnt where we have been asked that application team want alert if specified folder does not contain any .csv file with todays time stamp.
# Input Variables:
#   Default KPI is "STATUS"
# 	The script takes multiple arguments as "Component Instance  and Task Path" in pairs ":" separated
# Component Instance: will be the short name for files of service to be monitored
# Powershell version required is 5 and above.
# Output Variables:
#It will return value 0 if any latest .csv file present in specified folder else it will return 1 which indicates latest file is not present.
#Path from where files to be monitored is to be mentioned in conf/config.ps1 input file.

Param(
	[switch]$v = $false,
	[switch]$h = $false
)


# Function to display usage
Function Usage
{
	write-host "Usage"
	write-host "	The script reads the folder name from conf file & returns the status of latest file presence:"
	write-host "	.\Monitor_LatestTimeStamp_File_In_Folder.ps1"
}

# Print version
if($v){
	write-host "VERSION IS 2.0"
	exit
}

# Print help message
if($h){
	Usage
	exit
}

if( $args.Count -gt 0) {
    write-host "Invalid arguments passed"
    Usage
	exit
   }

$BASE_DIR = split-path -parent $MyInvocation.MyCommand.Definition
$LogDay = Get-Date -Format "dd-MMM-yyyy"
$CONFIG_DIR = "$BASE_DIR\conf"
$CONFIG_FILE = "$CONFIG_DIR\Config.ps1"
$LOG_DIR = "$BASE_DIR\log\$LogDay"
$LOG_FILE = "$LOG_DIR\Monitor_LatestTimeStamp_File_In_Folder.log"
$TMP_DIR= "$BASE_DIR\tmp"




# Create log folder if doesn't exist
If(!(test-path $LOG_DIR)) {
	New-Item -ItemType Directory -Force -Path $LOG_DIR | out-null
}


# Create tmp folder if doesn't exist
If(!(test-path $TMP_DIR)) {
	New-Item -ItemType Directory -Force -Path $TMP_DIR | out-null
}

# Function for writing log
Function Logwrite
{
	Param ([string]$logstring)
	$mark=Get-Date
	Add-content $LOG_FILE -value "$mark : INFO $logstring"
}

## Exit script function definition
Function Exit_Script([string]$exitstring)
{

	If((test-path $TMP_DIR)) {
	Remove-Item -path "$TMP_DIR" -recurse | out-null
	}
	Logwrite "$exitstring"
	[int]$Purge_Days = $Purge_Days
    if ($?) {
	Logwrite "Purge days : $Purge_Days"
	} else {
        Logwrite "Invalid log purge days defined."
        Logwrite "Considering default as 2"
        $Purge_Days = 2
    }

	if ( (!$Purge_Days) -and ($Purge_Days -eq 0) ) {
		$Purge_Days = 2
	}
    if ( $Purge_Days -ge 0 ) {
        Logwrite "Clearing log files and folders older than $Purge_Days days"
	    Get-ChildItem -Path "$BASE_DIR\log" |Where-Object {$_.psiscontainer -and $_.lastwritetime -le (Get-Date).adddays(-$Purge_Days)} |ForEach-Object {Remove-Item $BASE_DIR\log\$_ -Recurse -Force}
    } else {
        Logwrite "Purge log days values should be >= 1"
    }
    Logwrite "---------------------Execution finished-------------------"
	Exit
}



# Function to write to request/response xml file
Function xmlWrite($xmlfile,$logstring )
{
   Add-content $xmlfile -value $logstring
}

Function xmlTmpWrite ($KPI_NAME,$VALUE)
{
	$tmpxmlfile = "$TMP_DIR\tmp.xml"
   	$mytime = ((get-date).addhours(-5).addminutes(-30)).ToString('yyyy-MM-dd HH:mm:ss')
	xmlwrite $tmpxmlfile "<ComponentInstance name=`"$COMPONENT_INST`" component=`"$COMPONENT`" enterprise=`"$ENTERPRISE`" >"
	xmlwrite $tmpxmlfile "<KPIs>"
	xmlwrite $tmpxmlfile "<KPI name=`"$KPI_NAME`" value=`"$VALUE`"/>"
    xmlwrite $tmpxmlfile "<KPI name=`"Time`" value=`"$mytime`"/>"
	xmlwrite $tmpxmlfile "</KPIs>"
	xmlwrite $tmpxmlfile "</ComponentInstance>"

}

Function sendtoappsone()
{
	$tmpxmlfile = "$TMP_DIR\tmp.xml"
	$reqxmlfile = "$TMP_DIR\Request.xml"
	$resxmlfile = "$TMP_DIR\Response.xml"
	if ( Test-Path $reqxmlfile) { Remove-Item $reqxmlfile }
	if ( Test-Path $resxmlfile) { Remove-Item $resxmlfile }
	xmlwrite $reqxmlfile "<A1 xsi:noNamespaceSchemaLocation=`"A1DCASchema.xsd`" xmlns:xsi=`"http://www.w3.org/2001/XMLSchema-instance`">"
	xmlwrite $reqxmlfile "<A1Request id=`"$AGENT_ID`" version=`"1.0`" mode=`"MONITOR`">"
	xmlwrite $reqxmlfile "<Data>"

	Add-content "$reqxmlfile" -value (get-content "$tmpxmlfile")

	xmlwrite $reqxmlfile "</Data>"
	xmlwrite $reqxmlfile "</A1Request>"
	xmlwrite $reqxmlfile "</A1>"

	Logwrite "xml created as below:"
	add-content $LOG_FILE -value (get-content "$reqxmlfile")

	$content = [IO.File]::ReadAllText($reqxmlfile)
$reqBody = @"
$content
"@
	Logwrite "Trying to send data to appsone"
try {
	$endPoint = "http://"+$HOST_NAME+":"+"$PORT_/$URL"
	$wr = [System.Net.HttpWebRequest]::Create($endPoint)
	$wr.Method= 'POST';
	$wr.ContentType="application/xml";
	$Body = [byte[]][char[]]$reqBody;
	$wr.Timeout = 10000;
	$Stream = $wr.GetRequestStream();
	$Stream.Write($Body, 0, $Body.Length);
	$Stream.Flush();
	$Stream.Close();
	$resp = $wr.GetResponse().GetResponseStream()
	$sr = New-Object System.IO.StreamReader($resp)
	$respTxt = $sr.ReadToEnd()
	Logwrite "Response Below:"
	Add-content $LOG_FILE -value $respTxt
	}
catch {
	$errorStatus = "Exception Message: " + $_.Exception.Message;
	Logwrite "$errorStatus"
}

}


function Process
{

for($i=0; $i -lt $arg_cnt; $i++)
{
	$line = $($DETAILS[$i])
	if (!$line) { continue }
	$KPI_NAME="FILE_STATUS"
    $BASE_DIR=$(Get-location).path

	#Mention Directory to Monitor
	$PATH=$DETAILS[0]

	#Apply Filters based on file extension
	$filter="*.txt"

	#Get the Latest file and Its TimeStamp
	$latest = Get-ChildItem -Path $PATH -Filter $filter | Sort-Object LastWriteTime -Descending | Select-Object -First 1
	$LastModifiedDate=get-date([datetime]$latest.LastWriteTime) -Format g
	
	#Get Current date for comparison
	$CurrentDate=get-date -Format g
	
	if($LastModifiedDate -lt $CurrentDate)
		{
			Write-Host "-----> Updated File Missing <-------- "
			Write-Host "Path for lookup" $PATH
			Write-Host "Last Modified" $LastModifiedDate
			Write-Host "Current Date" $CurrentDate
			Write-Host "Last Updated file"$latest.FullName
			$STATUS=1;  xmlTmpWrite ($KPI_NAME)($STATUS)
			}
			else
			{
			Write-Host "-----> File Present <-------- "
			Write-Host "Path for lookup" $PATH
			Write-Host "Last Modified" $LastModifiedDate
			Write-Host "Current Date" $CurrentDate
			Write-Host "Last Updated file"$latest.FullName
			$STATUS=0;  xmlTmpWrite ($KPI_NAME)($STATUS)
			
		}
}
 sendtoappsone
 return

}

Logwrite "-----------------------Execution started--------------------"

Function Main() {



	# Check if collection service ip is configure or not
	if (!$HOST_NAME ){
    	Logwrite "Collection service ip is not defined in the config file "
        return
    }

	# Check if collection service port is configure or not
	if (!$PORT_ ){
    	Logwrite "Collection service port is not defined in the config file "
        return
    }

	# Check if enterprise name is configure or not
	if (!$ENTERPRISE ){
    	Logwrite "ENTERPRISE name is not defined in the config file "
        return
    }

	# Check if component name is configure or not
	if (!$COMPONENT ){
    	Logwrite "Component name is not defined in the config file "
        return
    }


	# Check if agent identifier is configure or not
	if (!$AGENT_ID ){
    	Logwrite "Agent identifier is not defined in the config file "
        return
    }

	# Check if url ip is configure or not
	if (!$URL ){
    	Logwrite "Collection service url is not defined in the config file "
        return
    }

	Process
    return
}


# Check if config file is present
if ( -not (Test-Path $CONFIG_FILE)) {
LogWrite "Config file is missing Exit the script"
exit
}
Logwrite "----Config.ps1 Processing started----"
Logwrite "Reading variables from Config.ps1"
. $CONFIG_FILE

	if ($?) {
        Logwrite "Config.ps1 included"
		$arg_cnt = $Details.Count

    } else {

		Logwrite "Config.ps1 inclusion failed"
        Exit_Script "Exiting the script"
    }
Main
Exit_Script "Processing finished"

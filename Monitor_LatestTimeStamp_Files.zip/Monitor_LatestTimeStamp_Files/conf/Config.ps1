# Please do not leave any of the fields blank.

# Update the below with appsone collection service details
# Enterprise name should not be display name
$HOST_NAME = "10.50.52.118"
$PORT_ = 9111
$ENTERPRISE = "HDFC"
$COMPONENT = "Latest_File_Present"
$COMPONENT_INST = "DNC_PROCESS_123"

$AGENT_ID = "248c75ad-2c99-4773-bbef-8af9e31439c7"
$URL = "CollectionServiceData"

##Define KPI related Details
#$KPI_NAME = "PROCESSS_STATUS"
## <COMPONENT_INST>:<TASKPATH>
$DETAILS = @{}
$DETAILS[0] = "D:\\temppp"

# Number of days to retain log
$Purge_Days = 1